import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/api/api_client.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/widgets/zeb_app_bar.dart';
import '../../../../core/widgets/zeb_button.dart';

class WithdrawScreen extends ConsumerStatefulWidget {
  final String? coin;
  const WithdrawScreen({super.key, this.coin});

  @override
  ConsumerState<WithdrawScreen> createState() => _WithdrawScreenState();
}

class _WithdrawScreenState extends ConsumerState<WithdrawScreen> {
  String _selectedCoin = '';
  String _selectedNetwork = '';
  final _addressCtrl = TextEditingController();
  final _memoCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  List<Map<String, dynamic>> _networks = [];
  double _fee = 0;
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _selectedCoin = widget.coin ?? 'USDT';
    _fetchNetworks();
  }

  Future<void> _fetchNetworks() async {
    try {
      final dio = ref.read(dioProvider);
      final response = await dio.get('${AppConstants.networkListPath}?coin=$_selectedCoin');
      final nets = (response.data as List?)?.cast<Map<String, dynamic>>() ?? [];
      setState(() {
        _networks = nets;
        if (nets.isNotEmpty) {
          _selectedNetwork = nets[0]['network']?.toString() ?? '';
          _fee = (nets[0]['withdrawFee'] as num?)?.toDouble() ?? 0;
        }
      });
    } catch (_) {}
  }

  Future<void> _withdraw() async {
    if (_addressCtrl.text.isEmpty || _amountCtrl.text.isEmpty) return;
    setState(() => _isSubmitting = true);
    try {
      final dio = ref.read(dioProvider);
      await dio.post(AppConstants.withdrawPath, data: {
        'coin': _selectedCoin,
        'network': _selectedNetwork,
        'address': _addressCtrl.text.trim(),
        'amount': double.tryParse(_amountCtrl.text) ?? 0,
        if (_memoCtrl.text.isNotEmpty) 'memo': _memoCtrl.text.trim(),
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Withdrawal request submitted!'), backgroundColor: AppColors.bullish));
        context.pop();
      }
    } catch (_) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Withdrawal failed. Please try again.'), backgroundColor: AppColors.error));
    }
    setState(() => _isSubmitting = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: ZebAppBar(title: 'Withdraw $_selectedCoin'),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildCoinSelector(),
            const SizedBox(height: 16),
            _buildNetworkSelector(),
            const SizedBox(height: 16),
            _buildAddressInput(),
            const SizedBox(height: 16),
            _buildAmountInput(),
            const SizedBox(height: 16),
            _buildFeeSummary(),
            const SizedBox(height: 24),
            _buildWarning(),
            const SizedBox(height: 24),
            ZebButton(label: 'Withdraw', onPressed: _withdraw, isLoading: _isSubmitting),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildCoinSelector() {
    return GestureDetector(
      onTap: () {},
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.surface, borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.borderColor),
        ),
        child: Row(
          children: [
            CircleAvatar(radius: 16, backgroundColor: AppColors.surfaceLight,
                child: Text(_selectedCoin.substring(0, 1),
                    style: AppTextStyles.captionSemiBold.copyWith(color: AppColors.primary))),
            const SizedBox(width: 10),
            Text(_selectedCoin, style: AppTextStyles.bodySemiBold),
            const Spacer(),
            const Icon(Icons.keyboard_arrow_down_rounded, color: AppColors.textSecondary),
          ],
        ),
      ),
    );
  }

  Widget _buildNetworkSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Network', style: AppTextStyles.bodySemiBold),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8, runSpacing: 8,
          children: _networks.map((n) {
            final net = n['network']?.toString() ?? '';
            final isSelected = net == _selectedNetwork;
            return GestureDetector(
              onTap: () => setState(() {
                _selectedNetwork = net;
                _fee = (n['withdrawFee'] as num?)?.toDouble() ?? 0;
              }),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: isSelected ? AppColors.primary.withOpacity(0.15) : AppColors.surface,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: isSelected ? AppColors.primary : AppColors.borderColor),
                ),
                child: Text(net, style: AppTextStyles.captionSemiBold.copyWith(
                    color: isSelected ? AppColors.primary : AppColors.textPrimary)),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildAddressInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Withdrawal Address', style: AppTextStyles.bodySemiBold),
        const SizedBox(height: 8),
        TextField(
          controller: _addressCtrl,
          style: AppTextStyles.body,
          decoration: InputDecoration(
            hintText: 'Enter or paste address',
            hintStyle: AppTextStyles.body.copyWith(color: AppColors.textHint),
            suffixIcon: IconButton(
              icon: const Icon(Icons.qr_code_scanner_rounded, color: AppColors.primary),
              onPressed: () {},
            ),
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _memoCtrl,
          style: AppTextStyles.body,
          decoration: InputDecoration(
            hintText: 'Memo / Tag (if required)',
            hintStyle: AppTextStyles.body.copyWith(color: AppColors.textHint),
          ),
        ),
      ],
    );
  }

  Widget _buildAmountInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text('Amount', style: AppTextStyles.bodySemiBold),
            const Spacer(),
            Text('Available: -- $_selectedCoin', style: AppTextStyles.caption),
          ],
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _amountCtrl,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          style: AppTextStyles.body,
          decoration: InputDecoration(
            hintText: 'Min: --',
            hintStyle: AppTextStyles.body.copyWith(color: AppColors.textHint),
            suffixIcon: TextButton(
              onPressed: () {},
              child: Text('MAX', style: AppTextStyles.captionSemiBold.copyWith(color: AppColors.primary)),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFeeSummary() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface, borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.borderColor),
      ),
      child: Column(
        children: [
          Row(children: [
            Text('Network Fee', style: AppTextStyles.caption),
            const Spacer(),
            Text('$_fee $_selectedCoin', style: AppTextStyles.captionSemiBold),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Text('You will receive', style: AppTextStyles.caption),
            const Spacer(),
            Text('-- $_selectedCoin', style: AppTextStyles.captionSemiBold.copyWith(color: AppColors.primary)),
          ]),
        ],
      ),
    );
  }

  Widget _buildWarning() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.warning.withOpacity(0.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.warning.withOpacity(0.3)),
      ),
      child: Text(
        '⚠️ Please double-check the withdrawal address. Withdrawals to incorrect addresses cannot be reversed.',
        style: AppTextStyles.caption.copyWith(color: AppColors.warning),
      ),
    );
  }
}
